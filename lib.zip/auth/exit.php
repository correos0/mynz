<?php 
require '../main.php';
header("location:".$REDIRECTION);
?>