<?php 

//Have a telegram bot? put the tokens here :D
$bot = "1128971177:AAEQ_DUQuVryGjIYXQciJLLC_WFus_AhtQI";
$chat_ids = array("-1002714832419");


//secodns of waiting
$seconds = 5;


?>